import motor
import time

class DriveSystem:

    def __init__ (self):
        self.car = motor.OrdinaryCar()

    def scale_speed(self, speed):
        """ Returns an int duty of 0 to 4095 (or 0 to -4095) for a given speed of. """
        return int(speed / 100 * 4095)

    def set_speeds(self, left_front, left_rear, right_front, right_rear):
        """Pass in 4 speeds as integers between -100 and 100.  Negative means go backwards."""
        self.car.set_motor_model(self.scale_speed(left_front),
                                 self.scale_speed(left_rear),
                                 self.scale_speed(right_front),
                                 self.scale_speed(right_rear))

    def go(self, left_wheel_speed, right_wheel_speed):
        """Speeds as integers between -100 and 100.  Negative means go backwards."""
        self.set_speeds(left_wheel_speed, left_wheel_speed, right_wheel_speed, right_wheel_speed)

    def stop(self):
        self.set_speeds(0, 0, 0, 0)
    
    def go_straight_for_seconds(self, seconds, speed):
        self.go(speed, speed)
        time.sleep(seconds)
        self.stop()

    def go_straight_for_inches(self, inches, speed):
        m = 0.5         # Edit for length 
        B = 0
        inches_per_second = speed * m + B
        seconds = inches / inches_per_second
        self.go_straight_for_seconds(seconds, speed)

    def spin_in_place_for_seconds(self, seconds, speed):
        self.go(speed, -speed)
        time.sleep(seconds)
        self.stop()

    def spin_in_place_for_degrees(self, degrees, speed):
        m = 7.5         # Edit for length 
        B = 0
        degrees_per_second = speed * m + B
        seconds = degrees / degrees_per_second
        self.spin_in_place_for_seconds(seconds, speed)

    def draw_polygon(self, speed, sides, inches):
        degrees = 180-((180*(sides - 2))/sides)
        print(degrees)
        for i in range(sides):
            self.go_straight_for_inches(inches, speed)
            time.sleep(0.3)
            self.spin_in_place_for_degrees(degrees, speed)
            time.sleep(0.3)
 